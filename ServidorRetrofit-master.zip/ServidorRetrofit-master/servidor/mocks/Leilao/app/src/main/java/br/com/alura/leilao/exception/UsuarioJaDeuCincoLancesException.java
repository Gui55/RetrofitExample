package br.com.alura.leilao.exception;

public class UsuarioJaDeuCincoLancesException extends RuntimeException {
}
