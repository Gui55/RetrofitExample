package br.com.alura.leilao.exception;

public class LanceMenorQueUltimoLanceException extends RuntimeException {
}
