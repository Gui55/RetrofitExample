package br.com.alura.leilao.ui.activity;

interface LeilaoConstantes {
    String CHAVE_LEILAO = "leilao";
}
